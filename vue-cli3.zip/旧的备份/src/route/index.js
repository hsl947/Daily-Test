import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);
export default new VueRouter({
  mode: "hash",
  routes: [
    {
      path: "/",
      name: 'index',
      component: resolve => require(["../views/Home"], resolve),
      meta: {
        index: 0,
        title: '首页'
      },
      children: []
    },
    {
      path: "/login",
      name: 'login',
      component: resolve => require(["../components/demo"], resolve),
      meta: {
        index: 1,
        title: 'login'
      },
      children: []
    }
  ]
});
