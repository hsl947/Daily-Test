<template>
  <div class="home">
    <router-link to="/login">Go to Bar</router-link>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "home",
  components: {
    
  }
};
</script>
