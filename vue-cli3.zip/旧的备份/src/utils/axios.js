import axios from 'axios'
import Router from '../route'

axios.defaults.timeout = 10000 //设置超时时间
axios.defaults.headers['token'] = 'AUTH_TOKEN';
axios.defaults.headers['Content-Type'] = 'multipart/form-data';

//use--get=> this.axios.get('*').then(function (response) {});
//use--post=> this.axios.post('*', {}).then(function (response) {});

// 添加请求拦截器
axios.interceptors.request.use(
    config => {        
        return config
    },
    error => {
        return Promise.reject(error)
    }
)

// 添加响应拦截器
axios.interceptors.response.use(
    response => {
        // 检测某种状态进行重定向
        if (response.data.code === 401) {
            Router.push({
                name: 'login'
            })
        }
        return response
    },
    error => {
        return Promise.resolve(error.response)
    }
)

export default axios;