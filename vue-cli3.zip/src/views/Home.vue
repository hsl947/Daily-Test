<template>
  <div>
    <div class="header">
        <span class="title">WISEMAN手机</span>
    </div>
    <van-swipe :autoplay="3000" indicator-color="white" class="banner">
        <van-swipe-item v-for="(img, index) in banners" :key="index">
            <img :src="img" alt="">
        </van-swipe-item>
    </van-swipe>
    <div class="detail-imgs">
        <img src="@/assets/images/detail/1.jpg" alt="">
        <img src="@/assets/images/detail/2.jpg" alt="">
    </div>
    <div class="btm-buy">
        <a class="buy-btn" @click="toBuy">立即购买</a>
    </div>
  </div>
</template>

<script>
import { Swipe, SwipeItem } from 'vant';

export default {
  name: "home",
  data() {
    return {
        swiperOption: {
            autoplay: true,
            pagination: {
                el: '.swiper-pagination'
            }
        },
        banners: []
    }
  },
  components: {
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem
  },
  methods: {
    toBuy() {
        let token = localStorage.getItem('token');
        if(token){
            this.$router.push({
                name: 'buyDetail'
            });
        }else{
            this.$router.push({
                name: 'register',
                query: {redirect: '/buyDetail'}
            });
        }
    }
  },
  mounted() {
        let that = this;
        this.axios.post('product.banner').then(function (_data) {
            if(_data.status){
                that.banners = _data.data;
            }
        });

        //用户通过扫码进来，带推广码参数
        if(this.$route.query.u){
            localStorage.setItem('spread_uid', this.$route.query.u);
        }
  }
};
</script>
