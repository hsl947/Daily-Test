<template>
  <div>
    <div class="header">
        <span class="title">付款成功</span>
    </div>
    <div class="success-container">
        <span class="iconfont success-icon">&#xe63d;</span>
        <p class="success-text">付款成功</p>
        <p class="success-infos">恭喜您已成功购买WISEMAN手机；</p>
        <p class="success-infos">您可以关注下方公众号。</p>
        <p class="success-infos">查看订单详情及手机激活码信息</p>
        <img src="@/assets/images/wx-code.png" class="weixin-code" alt="">
    </div>
  </div>
</template>

<script>

export default {
  name: "paySuccess",
  data() {
    return {
      
    }
  },
  methods: {
    
  },
  mounted() {
    
  }
};
</script>

<style scoped>
  
</style>
