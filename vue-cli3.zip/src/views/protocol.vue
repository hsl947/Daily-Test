<template>
  <div>
    <div class="header">
        <a onclick="window.history.back()" class="iconfont back">&#xe669;</a>
        <span class="title">WISEMAN手机用户注册协议</span>
    </div>
    <div class="protocol-content">
        <p class="tit" v-text="content.title"></p>
        <p v-html="content.content"></p>
    </div>
    <div class="btm-buy">
        <a class="buy-btn" @click="agree">我已阅读并同意</a>
    </div>
  </div>
</template>

<script>

export default {
  name: "protocol",
  data() {
    return {
      content: '',
      redirectUrl: ''
    }
  },
  methods: {
    agree() {
      this.$router.replace({
          name: 'register',
          params: {isChecked: true},
          query: {redirect: this.redirectUrl}
      })
    }
  },
  mounted() {
    //登录前的路由地址
    if(this.$route.query.redirect){
        this.redirectUrl = this.$route.query.redirect;
    }
    let that = this;
    this.axios.post('platform.registerAgreement').then(function (_data) {
        if(_data.status){
          that.content = _data.data;
        }
    });
  }
};
</script>

<style scoped>
  .tit{
    font-weight: 900;
    color: #000;
    padding-bottom: .2rem ;
  }
</style>
