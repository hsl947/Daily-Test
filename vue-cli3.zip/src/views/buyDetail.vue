<template>
  <div>
    <div class="header">
        <a onclick="window.history.back()" class="iconfont back">&#xe669;</a>
        <span class="title">WISEMAN手机</span>
    </div>
    <div class="product-name">
        <img class="pro-img" :src="phoneInfo.image[0]" alt="">
        <div class="right-name">
            <p class="name" v-text="phoneInfo.title">名称名称名称名称名称名称</p>
            <p class="price" v-if="formData.is_replace == 1">¥ {{phoneInfo.market_price}}</p>
            <p class="price" v-else>¥ {{phoneInfo.replace_price}}</p>
        </div>
    </div>
    <div class="product-type">
        <div class="item" v-for="(item, index) in phoneInfo.options.color" :key="index">
            <div class="left">
                <span class="color-type" :style="{'background': item[0]}"></span>
                <span class="color-text" v-text="item[1]"></span>
            </div>
            <div class="right">
                <i class="iconfont minus" @click="minus(index)">&#xe643;</i>
                <span class="num" v-text="formData.options[index]">0</span>
                <i class="iconfont plus" @click="plus(index)">&#xe644;</i>
            </div>
        </div>
    </div>
    <div class="is-changed" v-if="phoneInfo.is_replace == 2">
        <input type="checkbox" class="form-checkbox" @click="setReplace(formData.is_replace)" v-model="formData.is_replace" :true-value="2" :false-value="1"> 是否置换?
    </div>
    <div class="receiver">
        <div class="item vux-1px-b">
            <label for="">收货人</label>
            <input type="text" class="form-input" v-model="formData.receiver_name" placeholder="请填写收货人">
        </div>
        <div class="item vux-1px-b">
            <label for="">联系电话</label>
            <input type="tel" class="form-input" v-model="formData.receiver_phone" placeholder="请填写联系电话" >
        </div>
        <div class="item vux-1px-b">
            <label for="">联系地址</label>
            <input type="text" class="form-input" v-model="pca" @click="showPicker" readonly placeholder="请选择联系地址">
            <i class="iconfont arrow">&#xe66a;</i>
        </div>
        <div class="item vux-1px-b">
            <label for="">详细地址</label>
            <input type="text" class="form-input" v-model="formData.ship_address_1" placeholder="请填写详细地址">
        </div>
    </div>
    <div class="btm-buy">
        <p class="total">
            共 <span class="num" v-text="total.num"></span> 件商品 小计：
            小计：<span class="price">¥{{total.price}}</span>
        </p>
        <input class="buy-btn" @click="showType" :disabled="btnStatus" type="button" value="立即购买">
    </div>
    <!-- 弹窗 -->
    <div class="buy-popup area-picker" :class="{'showPopup': showPayType}">
        <div class="item">
            <div>
                <i class="iconfont ali">&#xe63b;</i>
                <span class="pay-type">支付宝</span>
            </div>
            <input type="checkbox" class="form-checkbox">
        </div>
        <div class="item">
            <div>
                <i class="iconfont wx">&#xe65b;</i>
                <span class="pay-type">微信</span>
            </div>
            <input type="checkbox" class="form-checkbox">
        </div>
        <div class="btm-buy">
            <input class="buy-btn" @click="submit" :disabled="btnStatus" type="button" value="立即支付">
        </div>
    </div>
    <div class="mask" v-if="showDistPick || showPayType" @click="hidePicker"></div>
    <div class="area-picker" :class="{'showPopup': showDistPick}">
        <v-distpicker type="mobile" @selected="onSelected"></v-distpicker>
    </div>
  </div>
</template>

<script>
import VDistpicker from 'v-distpicker'
export default {
    name: "protocol",
    data() {
        return {
            btnStatus: false,
            showDistPick: false,
            showPayType: false,
            phoneInfo: {
                image: [],
                options: {
                    color: []
                }
            },
            pca: '', //省市区显示
            formData: {
                options: {},
                is_replace: 1,
                promotion_code: localStorage.getItem('spread_uid')?localStorage.getItem('spread_uid'): '',
                receiver_name: '',
                receiver_phone: '',
                ship_state: '',
                ship_city: '',
                ship_area: '',
                ship_address_1: ''
            },
            total: {
                num: 0,
                price: 0
            },
            pay_timer: null
        }
    },
    components: { 
      VDistpicker 
    },
    methods: {
        showPicker() {
            this.showDistPick = true;
        },
        hidePicker() {
            this.showDistPick = false;
            this.showPayType = false;
        },
        onSelected(data) {
            console.log(data)
            this.pca = data.province.value + data.city.value + data.area.value;
            this.formData.ship_state = data.province.code;
            this.formData.ship_city = data.city.code;
            this.formData.ship_area = data.area.code;
            this.showDistPick = false;
        },
        countAll() {
            //计算总价
            delete this.formData.options['i'];
            this.total = {
                num: 0,
                price: 0
            };
            for(let k in this.formData.options){
                this.total.num += this.formData.options[k];
            }
            if(this.formData.is_replace == 1){//不置换，以市场价
                this.total.price = this.phoneInfo.market_price * this.total.num;
            }else{
                this.total.price = this.phoneInfo.replace_price * this.total.num;
            }       
        },
        plus(i) {
            //循环下要更新视图，手动修改数组
            this.formData.options[i]++;
            this.$set(this.formData.options, 'i', 0);
            this.$set(this.formData.options, i, this.formData.options[i]);
            this.countAll();
        },
        minus(i) {
            if(this.formData.options[i]>0){
                this.formData.options[i]--;
                this.$set(this.formData.options, 'i', this.formData.options[i]);
                this.$set(this.formData.options, i, this.formData.options[i]);
                this.countAll();
            }
        },
        setReplace(v) {
            let that = this;
            setTimeout(function() {
                that.countAll();
            })
        },
        submit() {
            let that =this;
            delete this.formData.options['i'];
            this.btnStatus = true;
            this.$toast.loading({
                mask: true,
                message: '购买中...'
            });
            this.axios.post('sales.buyPhone', this.formData).then(function (_data) {
                if(_data.status&&_data.code == 6014){
                    let oid = _data.data.oid;
                    //轮询检查支付结果
                    that.pay_timer = setInterval(function(){
                        that.checkPay(oid);
                    }, 3000);
                }else{
                    that.btnStatus = false;
                    that.$toast.fail(_data.msg);
                }
            });
        },
        checkPay(order_num) {
            let that = this;
            this.axios.post('sales.payOk', {oid: order_num}).then(function (_data) {
                if(_data.status&&_data.code == 6018){
                    window.clearInterval(that.pay_timer);
                    that.$toast.success(_data.msg);
                    that.$router.replace({
                        name: 'paySuccess'
                    });
                }else if(_data.code == 6015 || _data.code == 6016 || _data.code == 6017 || _data.code == 6019 ){
                    window.clearInterval(that.pay_timer);
                    that.$toast.fail(_data.msg);
                }
            });
        },
        showType() {
            if(!this.formData.receiver_name){
                this.$toast.fail('请填写收货人！');
                return;
            }
            if(!this.formData.receiver_phone){
                this.$toast.fail('请填写联系电话！');
                return;
            }
            if(!this.formData.ship_area){
                this.$toast.fail('请选择联系地址！');
                return;
            }
            if(!this.formData.ship_address_1){
                this.$toast.fail('请填写详细地址！');
                return;
            }
            this.showPayType = true;
        }
    },
    mounted() {
        let that = this;
        this.axios.post('product.phoneInfo').then(function (_data) {
          if(_data.status){
            that.phoneInfo =  _data.data;
            let colors = that.phoneInfo.options.color;
            for(let k in colors){//初始化购买数量为0
                that.formData.options[k] = 0;
            }
          }
      });
    }
};
</script>
