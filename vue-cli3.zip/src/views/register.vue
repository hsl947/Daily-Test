<template>
  <div>
    <div class="header shadow">
        <a onclick="window.history.back()" class="iconfont back">&#xe669;</a>
        <span class="title">注册</span>
    </div>
    <div class="login-container">
        <img class="logo" src="@/assets/images/logo.png" alt="">
        <div class="login-form">
            <div class="item vux-1px-b">
                <label for="">手机号码</label>
                <input type="tel" class="form-input" ref="phone" maxlength="11" v-model="formData.phone" onkeyup="this.value=this.value.replace(/[^0-9]/g,'')" onafterpaste="this.value=this.value.replace(/[^0-9]/g,'')" @input="checkPhone()" placeholder="请填写手机号码">
            </div>
            <div class="item vux-1px-b">
                <label for="">手机验证码</label>
                <input type="text" class="form-input" ref="code" v-model="formData.code" maxlength="6" placeholder="请填写手机验证码">
                <input type="button" class="get-code" @click="getCode" :class="{'disabled': sendStatus}" :disabled="sendStatus" :value="sendText">
            </div>
            <div class="item vux-1px-b">
                <label for="">设置密码</label>
                <input type="password" class="form-input" ref="password" v-model="formData.password" placeholder="请设置登录密码">
            </div>
            <router-link class="to-login" :to="{ name: 'login', query: { redirect: redirectUrl }}">已注册，立即登录</router-link>
            <input type="submit" @click="submit($event)" :class="{'disabled': btnStatus}" :disabled="btnStatus" class="sub-btn" value="立即注册">
            <div class="agreement">
                <input type="checkbox" class="form-checkbox" v-model="isCheck" value="true">
                <span> 我已阅读并同意</span>
                <router-link class="agreement-link" :to="{ name: 'protocol', query: { redirect: redirectUrl }}">《用户注册协议》</router-link>
            </div>
        </div>
    </div>
  </div>
</template>

<script>

export default {
  name: "login",
  data() {
    return {
        redirectUrl: '', //回调地址
        isCheck: false,
        formData: {
            phone: '',
            code: '',
            password: '',
            ver_token_key: ''
        }, // 要提交的数据集合
        sendStatus: false, //发送验证码点击状态
        sendText: '获取验证码',
        btnStatus: false, //提交按钮点击状态
    }
  },
  methods: {
    checkPhone() {
        //检查手机号是否存在
        let that = this;
        if(this.formData.phone&&this.formData.phone.length == 11){
            let p = {
                phone: this.formData.phone
            }
            this.axios.post('user.checkUserWeb', p).then(function (_data) {
                if(_data.code == 2001){
                  that.sendStatus = true;
                  that.$toast.fail(_data.msg);
                }else{
                  that.sendStatus = false;
                }
            });
        }
    },
    countDown(options) {
      let that = this;
      //倒计时
      var defaults = {
          time: 59
      };
      var opt = this.extendObj(defaults, options);
      var i = opt.time;

      that.sendStatus = true;
      that.sendText = i+"s";

      var timer = setInterval(function(){
          i--;
          if(i<1){
              that.sendStatus = false;
              that.sendText = '获取验证码';
              clearInterval(timer);
          }else{
              that.sendText = i+"s";
          }
      },1000);
    },
    getCode() {
        //获取验证码
        let that = this;
        let regx = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/;
        if(!this.formData.phone){
            that.$toast.fail('请先填写手机号！');
            this.$refs.phone.focus();
            return;
        }
        if(!regx.test(this.formData.phone)){
            that.$toast.fail('手机号格式不正确！');
            this.$refs.phone.focus();
            return;
        }
        that.sendStatus = true;
        let params = {
            type: 1,
            phone: this.formData.phone
        }
        this.axios.post('user.verification', params).then(function (_data) {
            if(_data.status){
                that.formData.ver_token_key = _data.data.ver_token_key;
                that.$toast.success(_data.msg);
                that.countDown();
            }else{
                that.sendStatus = false;
                that.$toast.fail(_data.msg);
            }
        });
    },
    submit(e) {
      e.preventDefault();
      let that = this;
      if(!that.isCheck){
          that.$toast.fail('请阅读并同意注册协议');
          return;
      }
      if(!this.formData.phone){
        this.$refs.phone.focus();
        that.$toast.fail('请填写手机号');
        return;
      }
      if(!this.formData.code){
        this.$refs.code.focus();
        that.$toast.fail('请填写验证码');
        return;
      }
      if(!this.formData.password){
        this.$refs.password.focus();
        that.$toast.fail('请设置登录密码');
        return;
      }
      this.btnStatus = true;
      this.axios.post('user.registerWeb', this.formData).then(function (_data) {
          if(_data.status){
            localStorage.removeItem('regData');
            that.$toast.success(_data.msg);
            that.store.commit('setInfo', _data.data);
            that.store.commit('setToken', _data.data.app_auth);
            that.$router.replace({
                name: 'buyDetail'
            });
          }else{
              that.btnStatus = false;
              that.$toast.fail(_data.msg);
          }
      });
    },
  },
  watch:{
      formData:{//深度监听，可监听到对象、数组的变化
          handler(val, oldVal){
              localStorage.setItem('regData', JSON.stringify(val));
          },
          deep:true
      }
  },
  mounted() {
        //登录前的路由地址
        if(this.$route.query.redirect){
            this.redirectUrl = this.$route.query.redirect;
        }
        //是否已阅读并同意协议
        if(this.$route.params.isChecked){
            this.isCheck = this.$route.params.isChecked;
        }  
        //防止用户误跳转其他页面后，已填写的数据消失
        let initDataStr = localStorage.getItem('regData');
        if(initDataStr){
            let initData = JSON.parse(initDataStr);
            if(Object.keys(initData).length){
                for(let k in initData){
                    this.formData[k] = initData[k];
                }
            }
            this.checkPhone();
        }
  }
};
</script>
