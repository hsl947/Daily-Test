<template>
  <div>
    <div class="header">
        <span class="title">WISEMAN手机</span>
    </div>
    <div class="user-name">
        <i class="iconfont">&#xe615;</i>
        <span class="name" v-text="phone">-</span>
    </div>
    <p class="common-title">我的购机记录</p>
    <van-list
    v-model="loading"
    :finished="finished"
    finished-text="- 到底啦 -"
    @load="onLoad"
    >
        <div class="buy-records">
            <div class="item" v-for="item in orderList" :key="item.id" :class="{'send': item.is_ship == 2, 'actived': item.is_activation == 2, 'not-send': item.is_ship == 1}">
                <div class="row">
                    <span class="name">推荐购买人 <i v-text="item.promotion_user"></i></span>
                    <span class="status" v-text="item.is_ship_name"></span>
                </div>
                <div class="row">
                    <span class="name">订单编号 <i v-text="item.order_no"></i></span>
                    <span class="time" v-text="item.create_time"></span>
                </div>
                <div class="btm-btns">
                    <a class="btn" href="#" v-if="item.is_ship == 2">查看物流</a>
                    <a class="btn disabled" v-if="item.is_ship != 2">查看物流</a>

                    <a class="btn" v-if="item.is_activation != 2" @click="showActiveCode(item)">激活码</a>
                    <a class="btn disabled" v-if="item.is_activation == 2">激活码</a>

                    <a class="btn" @click="showSpreadImg(item)">推广二维码</a>
                </div>
            </div>
        </div>
    </van-list>

    <!-- 弹窗 -->
    <div class="mask" v-if="show.img || show.code" @click="hidePopup"></div>
    <div class="scale-box" :class="{'showScale': show.img}">
        <div class="active-code-box">
            <p class="title">我的二维码</p>
            <img class="active-code" :src="spread.img" alt="">
            <a class="popup-btn" 
                v-clipboard:copy="spread.url"
                v-clipboard:success="onCopy"
                v-clipboard:error="onError">复制分享链接</a>
        </div>
    </div>
    <div class="scale-box" :class="{'showScale': show.code}">
        <div class="active-code-box">
            <p class="title">我的激活码</p>
            <input type="text" class="grey-input" readonly disabled :value="active.code">
            <a class="popup-btn"
                v-clipboard:copy="active.code"
                v-clipboard:success="onCopy"
                v-clipboard:error="onError">复制</a>
        </div>
    </div>
  </div>
</template>

<script>
import { List, Toast } from 'vant';

export default {
  name: "userCenter",
  data() {
    return {
      phone: '',
      formData: {
          page: 0,
          limit: 10
      },
      orderList: [],
      show: {
          img: false,
          code: false
      },
      spread: {
          img: '',
          url: ''
      },
      active: {
          code: ''
      },
      loading: false,
      finished: false
    }
  },
  components: {
      [List.name]: List
  },
  methods: {
        onLoad() {
            let that = this;
            this.formData.page++;
            this.axios.post('sales.orderList', this.formData).then(function (_data) {
                that.loading = false;
                if(_data.status == false || _data.data.list.length == 0){
                    that.finished = true;
                }else{
                    that.orderList = that.orderList.concat(_data.data.list);
                }
            });
        },
        getData() {
            this.loading = false;
    	    this.finished = false;
        },
        onCopy: function (e) {
            this.$toast.success('复制成功！');
        },
        onError: function (e) {
            this.$toast.fail('复制失败，请重试！');
        },
        showSpreadImg(item) {
            //显示推广二维码
            this.spread = {
                img: item.promotion_qr,
                url: item.promotion_url
            }
            this.show.img = true;
        },
        showActiveCode(item) {
            //显示推广激活码
            this.active = {
                code: item.activation_code
            }
            this.show.code = true;
        },
        hidePopup() {
            this.show = {
                img: false,
                code: false
            }
        }
  },
  mounted() {
        let user_info = localStorage.getItem('infos');
        this.phone = JSON.parse(user_info).phone;
        this.phone = this.phone.substring(0,3)+"*****"+this.phone.substring(7,11);
  }
};
</script>

<style scoped>
  
</style>
