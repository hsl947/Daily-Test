<template>
  <div>
    <div class="header shadow">
        <span class="title">登录</span>
    </div>
    <div class="login-container">
        <img class="logo" src="@/assets/images/logo.png" alt="">
        <div class="login-form">
            <div class="item vux-1px-b">
                <label for="">手机号码</label>
                <input type="tel" class="form-input" ref="phone" maxlength="11" v-model="formData.phone" onkeyup="this.value=this.value.replace(/[^0-9]/g,'')" onafterpaste="this.value=this.value.replace(/[^0-9]/g,'')" placeholder="请填写手机号码">
            </div>
            <div class="item vux-1px-b">
                <label for="">登录密码</label>
                <input type="password" class="form-input" ref="password" v-model="formData.password" placeholder="请填写登录密码">
            </div>
            <router-link class="to-login" :to="{ name: 'register', query: { redirect: redirectUrl }}">没有账号？立即注册</router-link>
            <input type="submit" class="sub-btn" @click="submit($event)" :class="{'disabled': btnStatus}" :disabled="btnStatus" value="登录">
        </div>
    </div>
  </div>
</template>

<script>

export default {
  name: "login",
  data() {
    return {
        redirectUrl: '', //回调地址
        formData: {
            phone: '',
            password: '',
        }, // 要提交的数据集合
        btnStatus: false, //提交按钮点击状态
    }
  },
  methods: {
    submit(e) {
      e.preventDefault();
      let that = this;
      if(!this.formData.phone){
        this.$refs.phone.focus();
        this.$toast.fail('请填写手机号');
        return;
      }
      if(!this.formData.password){
        this.$refs.password.focus();
        this.$toast.fail('请填写密码');
        return;
      }
      this.btnStatus = true;
      this.axios.post('user.signinWeb', this.formData).then(function (_data) {
          if(_data.status){
                that.$toast.success(_data.msg);
                that.store.commit('setInfo', _data.data);
                that.store.commit('setToken', _data.data.app_auth);
                if(that.redirectUrl){//登录前的路由
                    that.$router.replace({
                        path: that.redirectUrl
                    });
                }else{
                    that.$router.replace({
                        name: 'userCenter'
                    });
                }
          }else{
              that.btnStatus = false;
              that.$toast.fail(_data.msg);
          }
      });
    },
  },
  mounted() {
      //登录前的路由地址
      if(this.$route.query.redirect){
          this.redirectUrl = this.$route.query.redirect;
      }
  }
};
</script>
