import Vue from "vue";
import App from "./App.vue";
import router from "./route";
import store from "./store";
import FastClick from "fastclick";
import axios from './utils/axios'

Vue.prototype.axios = axios;
Vue.prototype.store = store;

FastClick.attach(document.body);

Vue.config.productionTip = false;

//动态设置title
router.beforeEach((to, from, next) => {
  document.title = to.meta.title;
  next()
});

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
