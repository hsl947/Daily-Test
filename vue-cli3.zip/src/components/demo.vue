<template>
    <div>q3e323</div>
</template>
<script>
export default {
  name: "demo"
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
