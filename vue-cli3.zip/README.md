# vue-cli3

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```
## 项目使用方法
#打包后，把public下的整个wap目录删掉，把dist文件夹下的wap目录整个剪切过去，上传即可。
